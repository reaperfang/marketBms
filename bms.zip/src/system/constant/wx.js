export default {

      color: [
            {
                  hex: '#FF6666',
                  wxhex: 1
            },
            {
                  hex: '#FFA77D',
                  wxhex: 2
            },
            {
                  hex: '#FFFFFF',
                  wxhex: 3
            },
            {
                  hex: '#000000',
                  wxhex: 4
            },
            {
                  hex: '#BCEEC5',                  
                  wxhex: 5
            }
      ]
}