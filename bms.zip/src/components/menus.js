export default {
    // {
        'childNode': [
          {
            'childNode': [
              {
                'icon': '',
                'id': 242,
                'menuLevel': 3,
                'menuName': '旅游订单',
                'menuTop': 1,
                'menuUrl': '/',
                'buttonControl': '0',
                'supMenuID': 241,
              },
              {
                'icon': '',
                'id': 243,
                'menuLevel': 3,
                'menuName': '签证订单',
                'menuTop': 2,
                'menuUrl': '/',
                'buttonControl': '0',
                'supMenuID': 241
              },
              {
                'icon': '',
                'id': 244,
                'menuLevel': 3,
                'menuName': '出团通知书',
                'menuTop': 3,
                'menuUrl': '/',
                'buttonControl': '0',
                'supMenuID': 241
              }
            ],
            'icon': '',
            'id': 241,
            'menuLevel': 2,
            'menuName': '订单管理',
            'menuTop': 1,
            'menuUrl': '/',
            'buttonControl': '0',
            'supMenuID': 240
          },
          {
            'childNode': [
              {
                'icon': '',
                'id': 246,
                'menuLevel': 3,
                'menuName': '旅游产品',
                'menuTop': 1,
                'menuUrl': '/tourProduct',
                'buttonControl': '0',
                'supMenuID': 245
              },
              {
                'icon': '',
                'id': 247,
                'menuLevel': 3,
                'menuName': '图库',
                'menuTop': 2,
                'menuUrl': '/basePicStore',
                'buttonControl': '0',
                'supMenuID': 245
              },
              {
                'icon': '',
                'id': 248,
                'menuLevel': 3,
                'menuName': '签证产品',
                'menuTop': 3,
                'menuUrl': '/',
                'buttonControl': '0',
                'supMenuID': 245
              }
            ],
            'icon': '',
            'id': 245,
            'menuLevel': 2,
            'menuName': '产品管理',
            'menuTop': 2,
            'menuUrl': '/',
            'buttonControl': '0',
            'supMenuID': 240
          },
          {
            'childNode': [
              {
                'icon': '',
                'id': 250,
                'menuLevel': 3,
                'menuName': '旅游广告',
                'menuTop': 1,
                'menuUrl': '/',
                'buttonControl': '0',
                'supMenuID': 249
              }
            ],
            'icon': '',
            'id': 249,
            'menuLevel': 2,
            'menuName': '广告管理',
            'menuTop': 3,
            'menuUrl': '/',
            'buttonControl': '0',
            'supMenuID': 240
          }
        ],
        'icon': '',
        'id': 240,
        'menuLevel': 1,
        'menuName': '业务中心',
        'menuTop': 1,
        'menuUrl': '/',
        'buttonControl': '0',
        'supMenuID': 0
    }
