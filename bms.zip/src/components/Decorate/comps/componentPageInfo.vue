<template>
  <!-- 页面信息 -->
  <div class="componentPageInfo" >
    页面信息
  </div>
</template>

<script>
import componentMixin from '../mixins/mixinComps';
export default {
  name: 'componentPageInfo',
  mixins:[componentMixin],
  components: {},
  data () {
    return {
      
    }
  },
  created() {

  },
  computed: {
    
  },
  methods: {
  }
}
</script>

<style lang="scss" scoped>
.componentPageInfo {
  
}
</style>
