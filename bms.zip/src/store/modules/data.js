const data = {
	state: {
		dataChart: {}
	},
	mutations: {
		flow: (state, index) => {
			state.dataChart = index
		}
	}
}

export default data