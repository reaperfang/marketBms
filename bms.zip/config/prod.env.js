module.exports = {
	NODE_ENV: '"production"',
	ENV_CONFIG: '"prod"',
	DATA_API: '"http://omo.aiyouyi.cn"',
	SALE_API: '"/mkt-api"',
	WEBSOCKET_server:'"ws://127.0.0.1:9000"',
	staticHost: 'https://test-m-aiyouyi.yun300.cn/',
	UPLOAD_SERVER:'"http://omo.aiyouyi.cn"',
}

